// models/Resume.js

const mongoose = require('mongoose');

const resumeSchema = new mongoose.Schema({
    fullName: String,
    email: String,
    phoneNumber: String,
    education: String,
    experience: String
});

module.exports = mongoose.model('Resume', resumeSchema);
