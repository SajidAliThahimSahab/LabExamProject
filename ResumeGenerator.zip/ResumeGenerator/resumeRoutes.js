// routes/resumeRoutes.js

const express = require('express');
const router = express.Router();
const Resume = require('../models/Resume');
const PDFDocument = require('pdfkit');
const fs = require('fs');

// Create Resume
router.post('/', async (req, res) => {
    try {
        const newResume = await Resume.create(req.body);
        res.status(201).json(newResume);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Read all Resumes
router.get('/', async (req, res) => {
    try {
        const resumes = await Resume.find();
        res.json(resumes);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Update Resume
router.patch('/:id', async (req, res) => {
    try {
        const updatedResume = await Resume.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedResume);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete Resume
router.delete('/:id', async (req, res) => {
    try {
        await Resume.findByIdAndDelete(req.params.id);
        res.json({ message: 'Deleted resume' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Generate PDF for a Resume
router.get('/:id/pdf', async (req, res) => {
    try {
        const resume = await Resume.findById(req.params.id);

        if (!resume) {
            res.status(404).json({ message: 'Resume not found' });
            return;
        }

        const doc = new PDFDocument();
        const filePath = `resume_${resume._id}.pdf`;
        doc.pipe(fs.createWriteStream(filePath));

        doc.fontSize(20).text('Resume Details', { align: 'center' }).moveDown();
        doc.fontSize(14).text(`Full Name: ${resume.fullName}`).moveDown();
        doc.text(`Email: ${resume.email}`).moveDown();
        doc.text(`Phone Number: ${resume.phoneNumber}`).moveDown();
        doc.text(`Education: ${resume.education}`).moveDown();
        doc.text(`Experience: ${resume.experience}`).moveDown();

        doc.end();

        res.json({ filePath }); // Return the file path for frontend use or further processing
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;
